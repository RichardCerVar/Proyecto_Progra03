/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.softbod.daoimp;

import pe.edu.pucp.softbod.dto.Categoria;
import pe.edu.pucp.softbod.dto.ProductoDTO;
import pe.edu.pucp.softbod.dto.Unidad_Medida;
import java.sql.SQLException;
import java.util.ArrayList;
import pe.edu.pucp.softbod.dao.ProductoDAO;
import pe.edu.pucp.softbod.daoimp.util.Columna;
import softdbmanager.db.DBManager;

/**
 *
 * @author sergi
 */
public class ProductoDAOImp extends DAOImplBase implements ProductoDAO {

    private ProductoDTO producto;
    
    public ProductoDAOImp() {
        super("Producto");
        this.producto=null;
        this.retornarLlavePrimaria=true;
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
    this.statement.setString(1, this.producto.getNombre());
    this.statement.setDouble(2, this.producto.getPrecio_unitario());
    this.statement.setString(3, this.producto.getCategoria().name());      // enum -> String
    this.statement.setString(4, this.producto.getUnidad_medida().name());  // enum -> String
    this.statement.setDouble(5, this.producto.getStock());
    this.statement.setDouble(6, this.producto.getStockMinimo());
}

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
    this.statement.setString(1, this.producto.getNombre());
    this.statement.setDouble(2, this.producto.getPrecio_unitario());
    this.statement.setString(3, this.producto.getCategoria().name());
    this.statement.setString(4, this.producto.getUnidad_medida().name());
    this.statement.setDouble(5, this.producto.getStock());
    this.statement.setDouble(6, this.producto.getStockMinimo());
    this.statement.setInt(7, this.producto.getProductoId()); // WHERE productoId = ?
}

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.producto.getProductoId()); // DELETE FROM Producto WHERE productoId = ?
    }
    
    @Override
    public ProductoDTO obtenerPorId(Integer productoId) {
        ProductoDTO productoDTO = null;
        try {
            this.conexion = DBManager.getInstance().getConnection();
            String sql = "SELECT id, nombre, precio_unitario, categoria, unidad_medida, stock, stock_minimo " +
                     "FROM Producto WHERE id = ?";
            this.statement = this.conexion.prepareCall(sql);
            this.statement.setInt(1, productoId);
            this.resultSet = this.statement.executeQuery();
            if (this.resultSet.next()) {
                productoDTO = new ProductoDTO();
                productoDTO.setProductoId(this.resultSet.getInt("id"));
                productoDTO.setNombre(this.resultSet.getString("nombre"));
                productoDTO.setPrecio_unitario(this.resultSet.getDouble("precio_unitario"));
                productoDTO.setCategoria(Categoria.valueOf(this.resultSet.getString("categoria")));       // String -> Enum
                productoDTO.setUnidad_medida(Unidad_Medida.valueOf(this.resultSet.getString("unidad_medida"))); // String -> Enum
                productoDTO.setStock(this.resultSet.getDouble("stock"));
                productoDTO.setStockMinimo(this.resultSet.getDouble("stock_minimo"));
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar obtenerPorId - " + ex);
        } finally {
            try {
                if (this.conexion != null) {
                    this.conexion.close();
                }
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
        return productoDTO;
    }

    @Override
    public ArrayList<ProductoDTO> listarTodos() {
        ArrayList<ProductoDTO> listaProductos = new ArrayList<>();
        try {
            this.conexion = DBManager.getInstance().getConnection();
            String sql = "SELECT id, nombre, precio_unitario, categoria, unidad_medida, stock, stock_minimo FROM Producto";
            this.statement = this.conexion.prepareCall(sql);
            this.resultSet = this.statement.executeQuery();
            while (this.resultSet.next()) {
                ProductoDTO productoDTO = new ProductoDTO();
                productoDTO.setProductoId(this.resultSet.getInt("id"));
                productoDTO.setNombre(this.resultSet.getString("nombre"));
                productoDTO.setPrecio_unitario(this.resultSet.getDouble("precio_unitario"));
                productoDTO.setCategoria(Categoria.valueOf(this.resultSet.getString("categoria")));          // String -> Enum
                productoDTO.setUnidad_medida(Unidad_Medida.valueOf(this.resultSet.getString("unidad_medida"))); // String -> Enum
                productoDTO.setStock(this.resultSet.getDouble("stock"));
                productoDTO.setStockMinimo(this.resultSet.getDouble("stock_minimo"));
                listaProductos.add(productoDTO);
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar listarTodos - " + ex);
        } finally {
            try {
                if (this.conexion != null) {
                    this.conexion.close();
                }
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
        return listaProductos;
    }

    @Override
    public Integer insertar(ProductoDTO producto){
        this.producto = producto;
        return super.insertar();
    }
    
    @Override
    public Integer modificar(ProductoDTO producto) {
        this.producto = producto;
        return super.modificar();
    }

    @Override
    public Integer eliminar(ProductoDTO producto) {
        this.producto = producto;
        return super.eliminar();
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("id",true,true));
        this.listaColumnas.add(new Columna("nombre",false,false));
        this.listaColumnas.add(new Columna("precio_unitario",false,false));
        this.listaColumnas.add(new Columna("categoria",false,false));
        this.listaColumnas.add(new Columna("unidad_medida",false,false));
        this.listaColumnas.add(new Columna("stock",false,false));
        this.listaColumnas.add(new Columna("stock_minimo",false,false));
    }
    
    
}
