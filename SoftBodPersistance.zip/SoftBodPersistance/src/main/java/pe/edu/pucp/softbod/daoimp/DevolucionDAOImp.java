package pe.edu.pucp.softbod.daoimp;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import pe.edu.pucp.softbod.dao.DevolucionDAO;
import pe.edu.pucp.softbod.daoimp.util.Columna;
import pe.edu.pucp.softbod.dto.DevolucionDTO;
import softdbmanager.db.DBManager;


public class DevolucionDAOImp extends DAOImplBase implements DevolucionDAO {

    private DevolucionDTO devolucion;
    
    public DevolucionDAOImp() {
        super("Devolucion");
        this.devolucion=null;
        this.retornarLlavePrimaria=true;
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("id",true,true));
        this.listaColumnas.add(new Columna("total",false,false));
        this.listaColumnas.add(new Columna("fecha",false,false));
    }

    @Override
    public DevolucionDTO obtenerPorId(Integer idDevolucion) {
        DevolucionDTO devolucionDTO = null;
        try {
            this.conexion = DBManager.getInstance().getConnection();
            String sql = "SELECT id, total, fecha" +
                     " FROM Devolucion WHERE id = ?";
            this.statement = this.conexion.prepareCall(sql);
            this.statement.setInt(1, idDevolucion);
            this.resultSet = this.statement.executeQuery();
            if (this.resultSet.next()) {
                devolucionDTO = new DevolucionDTO();
                devolucionDTO.setIdDevolucion(this.resultSet.getInt("id"));
                devolucionDTO.setTotal(this.resultSet.getDouble("total"));
                devolucionDTO.setFecha(this.resultSet.getTimestamp("fecha").toLocalDateTime());
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar obtenerPorId - " + ex);
        } finally {
            try {
                if (this.conexion != null) {
                    this.conexion.close();
                }
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
        return devolucionDTO;
    }

    @Override
    public ArrayList<DevolucionDTO> listarTodos() {
        ArrayList<DevolucionDTO> listaDevoluciones = new ArrayList<>();
        try {
            this.conexion = DBManager.getInstance().getConnection();
            String sql = "SELECT id, total, fecha FROM Devolucion";
            this.statement = this.conexion.prepareCall(sql);
            this.resultSet = this.statement.executeQuery();
            while(this.resultSet.next()){
                DevolucionDTO devolucionDTO = new DevolucionDTO();
                devolucionDTO.setIdDevolucion(this.resultSet.getInt("id"));
                devolucionDTO.setTotal(this.resultSet.getDouble("total"));
                devolucionDTO.setFecha(this.resultSet.getTimestamp("fecha").toLocalDateTime());
                listaDevoluciones.add(devolucionDTO);
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar listarTodos - " + ex);
        } finally {
            try {
                if (this.conexion != null) {
                    this.conexion.close();
                }
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
        return listaDevoluciones;
    }

    @Override
    public Integer insertar(DevolucionDTO devolucion) {
        this.devolucion = devolucion;
        return super.insertar();
    }
    
    @Override
    public Integer modificar(DevolucionDTO devolucion) {
        this.devolucion = devolucion;
        return super.modificar();
    }

    @Override
    public Integer eliminar(DevolucionDTO devolucion) {
        this.devolucion = devolucion;
        return super.eliminar();
    }
    
    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setDouble(1,this.devolucion.getTotal());
        this.statement.setTimestamp(2, Timestamp.valueOf(this.devolucion.getFecha()));
    }
    
    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setDouble(1,this.devolucion.getTotal());
        this.statement.setTimestamp(2, Timestamp.valueOf(this.devolucion.getFecha()));
        this.statement.setInt(3, this.devolucion.getIdDevolucion());
    }
    
    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1,this.devolucion.getIdDevolucion());
    }
    
}
