package pe.edu.pucp.softbod.daoimp.util;

public enum Tipo_Operacion {
    INSERTAR, MODIFICAR, ELIMINAR
}
