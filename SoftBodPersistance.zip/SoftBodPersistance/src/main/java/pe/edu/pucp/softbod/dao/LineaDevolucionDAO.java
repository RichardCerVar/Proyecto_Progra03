
package pe.edu.pucp.softbod.dao;

import java.util.ArrayList;
import pe.edu.pucp.softbod.dto.LineaDevolucionDTO;

public interface LineaDevolucionDAO {
    public Integer insertar(LineaDevolucionDTO linea);
    public LineaDevolucionDTO obtenerPorId(Integer idLinea);
    public ArrayList<LineaDevolucionDTO> listarTodos();
    public Integer modificar(LineaDevolucionDTO linea);
    public Integer eliminar(LineaDevolucionDTO linea);
}
