package pe.edu.pucp.softbod.daoimp;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import pe.edu.pucp.softbod.dao.LineaDevolucionDAO;
import pe.edu.pucp.softbod.daoimp.util.Columna;
import pe.edu.pucp.softbod.dto.LineaDevolucionDTO;
import pe.edu.pucp.softbod.dto.ProductoDTO;
import pe.edu.pucp.softbod.dto.Razon_Devolucion;
import softdbmanager.db.DBManager;

public class LineaDevolucionDAOImp extends DAOImplBase implements LineaDevolucionDAO {

    private LineaDevolucionDTO linea;

    public LineaDevolucionDAOImp() {
        super("Linea_Devolucion");
    }
    
    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("id",true,true));
        this.listaColumnas.add(new Columna("devolucion_id",false,false));
        this.listaColumnas.add(new Columna("producto_id",false,false));
        this.listaColumnas.add(new Columna("cantidad",false,false));
        this.listaColumnas.add(new Columna("subtotal",false,false));
        this.listaColumnas.add(new Columna("razon",false,false));
    }

    @Override
    public LineaDevolucionDTO obtenerPorId(Integer idLinea) {
       LineaDevolucionDTO lineaDevolucionDTO = null;
        try {
            this.conexion = DBManager.getInstance().getConnection();
            String sql = "SELECT id, devolucion_id, producto_id, cantidad, subtotal, razon" +
                     " FROM Linea_Devolucion WHERE id = ?";
            this.statement = this.conexion.prepareCall(sql);
            this.statement.setInt(1, idLinea);
            this.resultSet = this.statement.executeQuery();
            if (this.resultSet.next()) {
                lineaDevolucionDTO = new LineaDevolucionDTO();
                lineaDevolucionDTO.setLineaDevolucionId(this.resultSet.getInt("id"));
                lineaDevolucionDTO.setDevolucionId(this.resultSet.getInt("devolucion_id"));
                lineaDevolucionDTO.setProductoId(this.resultSet.getInt("producto_id"));
                lineaDevolucionDTO.setCantidad(this.resultSet.getDouble("cantidad"));
                lineaDevolucionDTO.setSubtotal(this.resultSet.getDouble("subtotal"));
                lineaDevolucionDTO.setRazon(Razon_Devolucion.valueOf(this.resultSet.getString("razon")));
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar obtenerPorId - " + ex);
        } finally {
            try {
                if (this.conexion != null) {
                    this.conexion.close();
                }
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
        return lineaDevolucionDTO;
    }

    @Override
    public ArrayList<LineaDevolucionDTO> listarTodos() {
        ArrayList<LineaDevolucionDTO> listaLineaDevoluciones = new ArrayList<>();
        try {
            this.conexion = DBManager.getInstance().getConnection();
            String sql = "SELECT id, devolucion_id, producto_id, cantidad, subtotal, razon FROM Linea_Devolucion";
            this.statement = this.conexion.prepareCall(sql);
            this.resultSet = this.statement.executeQuery();
            while(this.resultSet.next()){
                LineaDevolucionDTO lineaDevolucionDTO = new LineaDevolucionDTO();
                lineaDevolucionDTO.setLineaDevolucionId(this.resultSet.getInt("id"));
                lineaDevolucionDTO.setDevolucionId(this.resultSet.getInt("devolucion_id"));
                lineaDevolucionDTO.setProductoId(this.resultSet.getInt("producto_id"));
                lineaDevolucionDTO.setCantidad(this.resultSet.getDouble("cantidad"));
                lineaDevolucionDTO.setSubtotal(this.resultSet.getDouble("subtotal"));
                lineaDevolucionDTO.setRazon(Razon_Devolucion.valueOf(this.resultSet.getString("razon")));
                listaLineaDevoluciones.add(lineaDevolucionDTO);
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar listarTodos - " + ex);
        } finally {
            try {
                if (this.conexion != null) {
                    this.conexion.close();
                }
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
        return listaLineaDevoluciones;
    }

    @Override
    public Integer insertar(LineaDevolucionDTO linea) {
        this.linea = linea;
        return super.insertar();
    }
    
    @Override
    public Integer modificar(LineaDevolucionDTO linea) {
       this.linea = linea;
       return super.modificar();
    }

    @Override
    public Integer eliminar(LineaDevolucionDTO linea) {
        this.linea = linea;
        return super.eliminar();
    }
    
    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setInt(1, this.linea.getDevolucionId());
        this.statement.setInt(2, this.linea.getProductoId());
        this.statement.setDouble(1, this.linea.getCantidad());
        this.statement.setDouble(2, this.linea.getSubtotal());
        this.statement.setString(3, this.linea.getRazon().name());
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setInt(1, this.linea.getDevolucionId());
        this.statement.setInt(2, this.linea.getProductoId());
        this.statement.setDouble(1, this.linea.getCantidad());
        this.statement.setDouble(2, this.linea.getSubtotal());
        this.statement.setString(3, this.linea.getRazon().name());
        this.statement.setInt(4, this.linea.getLineaDevolucionId());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        // Solo se necesita el ID de la línea
        this.statement.setInt(1, this.linea.getLineaDevolucionId());
    }
    
}
