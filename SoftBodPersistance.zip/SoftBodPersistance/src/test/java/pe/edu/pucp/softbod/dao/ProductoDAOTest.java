package pe.edu.pucp.softbod.dao;

import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pe.edu.pucp.softbod.daoimp.ProductoDAOImp;
import pe.edu.pucp.softbod.dto.Categoria;
import pe.edu.pucp.softbod.dto.ProductoDTO;
import pe.edu.pucp.softbod.dto.Unidad_Medida;


public class ProductoDAOTest {
    
    private ProductoDAO productoDAO;
    
    public ProductoDAOTest() {
        this.productoDAO = new ProductoDAOImp();
    }


    @Test
    public void testInsertar() {
        System.out.println("----Insertar----");
        ArrayList<Integer> listaProductosId = new ArrayList<>();
        insertarProductos(listaProductosId);
        eliminarTodo();
    }

    
    public void insertarProductos(ArrayList<Integer> listaProductosId){       
        // Primer producto
        ProductoDTO p1 = new ProductoDTO();
        p1.setNombre("Azúcar ORO 1kg");
        p1.setPrecio_unitario(6.00);
        p1.setCategoria(Categoria.ALIMENTOS);
        p1.setUnidad_medida(Unidad_Medida.UNIDAD);
        p1.setStock(100.0);
        p1.setStockMinimo(20.0);
        Integer r1 = this.productoDAO.insertar(p1);
        assertTrue(r1 != 0);
        listaProductosId.add(r1);
        System.out.println("Insertado el producto con id "+ r1);
        
        
        // Segundo producto
        ProductoDTO p2 = new ProductoDTO();
        p2.setNombre("Jugo Naranja 1L");
        p2.setPrecio_unitario(4.50);
        p2.setCategoria(Categoria.BEBIDAS);
        p2.setUnidad_medida(Unidad_Medida.LITRO);
        p2.setStock(50.0);
        p2.setStockMinimo(10.0);
        Integer r2 = this.productoDAO.insertar(p2);
        assertTrue(r2 != 0);
        listaProductosId.add(r2);
        System.out.println("Insertado el producto con id "+ r2);
    }
    
    /**
     * Test of obtenerPorId method, of class ProductoDAO.
     */
    @Test
    public void testObtenerPorId() {
        System.out.println("----Obtener Por ID----");
        ArrayList<Integer> listaProductosId = new ArrayList<>();
        insertarProductos(listaProductosId);
        
        ProductoDTO producto = this.productoDAO.obtenerPorId(listaProductosId.get(0));
        System.out.println("Producto obtenido de la id "+ producto.getProductoId());
        assertEquals(producto.getProductoId(),listaProductosId.get(0));
        
        producto = this.productoDAO.obtenerPorId(listaProductosId.get(1));
        System.out.println("Producto obtenido de la id "+ producto.getProductoId());
        assertEquals(producto.getProductoId(),listaProductosId.get(1));
        
        eliminarTodo();
        
    }

    /**
     * Test of listarTodos method, of class ProductoDAO.
     */
    @Test
    public void testListarTodos() {
        System.out.println("----Listar Todos----");
        ArrayList<Integer> listaProductosId = new ArrayList<>();
        insertarProductos(listaProductosId);
        
        //verificacion
        ArrayList<ProductoDTO> listaProductos = this.productoDAO.listarTodos();
        assertEquals(listaProductosId.size(), listaProductos.size());
        for(Integer i=0; i <listaProductosId.size(); i++){
            assertEquals(listaProductosId.get(i), listaProductos.get(i).getProductoId());
        }
        
        // impresión de unos cuantos atributos
        System.out.println("Lista de productos: ");
        for (ProductoDTO p : listaProductos) {
            System.out.println(p.getProductoId() + " - " + p.getNombre() + " - " + p.getPrecio_unitario());
        }
        
        eliminarTodo();
    }

    /**
     * Test of modificar method, of class ProductoDAO.
     */
    @Test
    public void testModificar() {
        System.out.println("----Modificar----");
        ArrayList<Integer> listaProductosId= new ArrayList<>();
        insertarProductos(listaProductosId);
        
        ArrayList<ProductoDTO> listaProductos = this.productoDAO.listarTodos();
        assertEquals(listaProductosId.size(),listaProductos.size());
        
        //antes
        System.out.println("Lista de productos antes");
        for(ProductoDTO p : listaProductos){
            System.out.println(p.getProductoId() + " - " + p.getNombre() + " - " + p.getPrecio_unitario());
        }
        
        for(Integer i=0; i< listaProductosId.size(); i++){
            listaProductos.get(i).setNombre("NuevoNombreProducto " + i.toString());
            listaProductos.get(i).setPrecio_unitario(99.99);
            listaProductos.get(i).setCategoria(Categoria.MASCOTAS);
            this.productoDAO.modificar(listaProductos.get(i));
        }
        
        ArrayList<ProductoDTO> listaProductosModificado = this.productoDAO.listarTodos();
        
        //despues
        System.out.println("Lista de productos despues");
        for(ProductoDTO p : listaProductosModificado){
            System.out.println(p.getProductoId() + " - " + p.getNombre() + " - " + p.getPrecio_unitario());
        }
        
        //Verificacion de que la lista de productos modificados sea igual a la de la lista de productos antigua
        assertEquals( listaProductos.size(), listaProductosModificado.size());
        for(Integer i=0; i<listaProductos.size(); i++){
            assertEquals(listaProductos.get(i).getNombre(),listaProductosModificado.get(i).getNombre());
            assertEquals(listaProductos.get(i).getPrecio_unitario(),listaProductosModificado.get(i).getPrecio_unitario());
            assertEquals(listaProductos.get(i).getCategoria(),listaProductosModificado.get(i).getCategoria());
        }
        
    }

    /**
     * Test of eliminar method, of class ProductoDAO.
     */
    @Test
    public void testEliminar() {
        System.out.println("----eliminar----");
        ArrayList<Integer> listaProductosId = new ArrayList<>();
        insertarProductos(listaProductosId);
        // impresión de unos cuantos atributos
        for (Integer pid : listaProductosId) {
            System.out.println("Eliminado este producto con ID "+ pid);
        }
        eliminarTodo();
    }
    
    private void eliminarTodo(){
        ArrayList<ProductoDTO> listaProductos = this.productoDAO.listarTodos();
        for( Integer i=0; i < listaProductos.size(); i++){
            Integer resultado = this.productoDAO.eliminar(listaProductos.get(i));
            assertNotEquals(0,resultado);
            ProductoDTO producto = this.productoDAO.obtenerPorId(listaProductos.get(i).getProductoId());
            assertNull(producto);
        }
    }
    
}
