//package pe.edu.pucp.softbod.dao;
//
//import java.util.ArrayList;
//import org.junit.jupiter.api.Test;
//import static org.junit.jupiter.api.Assertions.*;
//import pe.edu.pucp.softbod.daoimp.LineaDevolucionDAOImp;
//import pe.edu.pucp.softbod.dto.DevolucionDTO;
//import pe.edu.pucp.softbod.dto.LineaDevolucionDTO;
//import pe.edu.pucp.softbod.dto.ProductoDTO;
//import pe.edu.pucp.softbod.dto.Razon_Devolucion;

//IMPORTANTE: Para poder probar las operaciones, ignorar las de Producto y Devolucion 
//comentar el @Test en esas clases por favor.

//ya que estas borran los datos.
//Ejecutar este query en mysql

/*-- Reiniciar AUTO_INCREMENT explícitamente
ALTER TABLE Producto AUTO_INCREMENT = 1;
ALTER TABLE Devolucion AUTO_INCREMENT = 1;
ALTER TABLE Linea_Devolucion AUTO_INCREMENT = 1;

-- Insertar productos de prueba
INSERT INTO Producto (nombre, precio_unitario, categoria, unidad_medida, stock, stock_minimo)
VALUES
('Azúcar ORO 1kg', 6.00, 'ALIMENTOS', 'UNIDAD', 100.00, 20.00),  -- id=1
('Jugo Naranja 1L', 4.50, 'BEBIDAS', 'LITRO', 50.00, 10.00);      -- id=2

-- Insertar devolución de prueba
INSERT INTO Devolucion (total, fecha)
VALUES
(0.00, NOW());  -- id=1

commit;*/

//public class LineaDevolucionDAOTest {
//    
//    private LineaDevolucionDAO lineaDevolucionDAO;
//
//    public LineaDevolucionDAOTest() {
//        this.lineaDevolucionDAO = new LineaDevolucionDAOImp();
//    }
//
//    /**
//     * Test of insertar method, of class LineaDevolucionDAO.
//     */
//    @Test
//    public void testInsertar() {
//        System.out.println("----Insertar----");
//        ArrayList<Integer> listaLineasId = new ArrayList<>();
//        insertarLineas(listaLineasId);
//        eliminarTodo();
//    }
//
//     private void insertarLineas(ArrayList<Integer> listaLineasId) {
//        // Línea 1
//        LineaDevolucionDTO ldev = new LineaDevolucionDTO();
////        l1.setDevolucionId(1); // depende de que exista una devolucion con id=1
////        l1.setProductoId(1);   // depende de que exista un producto con id=1
//        ldev.setCantidad(2.0);
//        ldev.setSubtotal(12.0);
//        ldev.setRazon(Razon_Devolucion.PRODUCTO_DEFECTUOSO);
//        Integer resultado = this.lineaDevolucionDAO.insertar(ldev);
//        
//        assertTrue(resultado != 0);
//        listaLineasId.add(resultado);
//        System.out.println("Insertada la lineaDev con id " + resultado);
//
//        // Línea 2
//        ldev = new LineaDevolucionDTO();
////        l2.setDevolucionId(1); // depende de que exista una devolucion con id=1
////        l2.setProductoId(2); // depende de que exista un producto con id=2
//        ldev.setCantidad(1.0);
//        ldev.setSubtotal(4.5);
//        ldev.setRazon(Razon_Devolucion.ERROR_EN_LA_VENTA);
//        resultado = this.lineaDevolucionDAO.insertar(ldev);
//        assertTrue(resultado != 0);
//        listaLineasId.add(resultado);
//        System.out.println("Insertada la lineaDev con id " + resultado);
//        eliminarTodo();
//    }
//    
//    /**
//     * Test of obtenerPorId method, of class LineaDevolucionDAO.
//     */
//    @Test
//    public void testObtenerPorId() {
//        System.out.println("----Obtener Por ID----");
//        ArrayList<Integer> listaLineasId = new ArrayList<>();
//        insertarLineas(listaLineasId);
//        
//        LineaDevolucionDTO linea = this.lineaDevolucionDAO.obtenerPorId(listaLineasId.get(0));
//        System.out.println("LineaDev obtenido de la id "+ linea.getLineaDevolucionId());
//        assertEquals(linea.getLineaDevolucionId(),listaLineasId.get(0));
//        
//        linea = this.lineaDevolucionDAO.obtenerPorId(listaLineasId.get(1));
//        System.out.println("LineaDev obtenido de la id "+ linea.getLineaDevolucionId());
//        assertEquals(linea.getLineaDevolucionId(), listaLineasId.get(1));
//        
//        eliminarTodo();
//        
//    }
//
//    /**
//     * Test of listarTodos method, of class LineaDevolucionDAO.
//     */
//    @Test
//    public void testListarTodos() {
//        System.out.println("----Listar Todos----");
//        ArrayList<Integer> listaLineasId = new ArrayList<>();
//        insertarLineas(listaLineasId);
//        
//        //verificacion
//        ArrayList<LineaDevolucionDTO> listaLineas = this.lineaDevolucionDAO.listarTodos();
//        assertEquals(listaLineasId.size(), listaLineas.size());
//        
//        // impresión de unos cuantos atributos
//        System.out.println("Lista de lineas de devolucion: ");
//        for (LineaDevolucionDTO l : listaLineas) {
//            System.out.println(l.getLineaDevolucionId() + " - " + l.getCantidad() + " - " + l.getSubtotal() + " - " + l.getRazon());
//        }
//        
//        eliminarTodo();
//    }
//
//    /**
//     * Test of modificar method, of class LineaDevolucionDAO.
//     */
//    @Test
//    public void testModificar() {
//        System.out.println("----Modificar----");
//        ArrayList<Integer> listaLineasId= new ArrayList<>();
//        insertarLineas(listaLineasId);
//        ArrayList<LineaDevolucionDTO> listaLineas = this.lineaDevolucionDAO.listarTodos();
//        assertEquals(listaLineasId.size(),listaLineas.size());
//        
//        //antes
//        System.out.println("Lista de lineasDev antes");
//        for(LineaDevolucionDTO l : listaLineas){
//             System.out.println(l.getLineaDevolucionId() + " - " + l.getCantidad() + " - " + l.getSubtotal());
//        }
//        
//        for(Integer i=0; i<listaLineas.size(); i++){
//            listaLineas.get(i).setCantidad(99.00);
//            listaLineas.get(i).setSubtotal(99.99);
//            listaLineas.get(i).setRazon(Razon_Devolucion.OTRO);
//            this.lineaDevolucionDAO.modificar(listaLineas.get(i));
//        }
//
//        ArrayList<LineaDevolucionDTO> listaLineasModificado = this.lineaDevolucionDAO.listarTodos();
//        
//        //despues
//        System.out.println("Lista de lineasDev despues");
//        for(LineaDevolucionDTO l : listaLineasModificado){
//             System.out.println(l.getLineaDevolucionId() + " - " + l.getCantidad() + " - " + l.getSubtotal());
//        }
//        
//        //Verificacion de que la lista de productos modificados sea igual a la de la lista de productos antigua
//        assertEquals( listaLineas.size(), listaLineasModificado.size());
//        for( Integer i=0; i<listaLineas.size(); i++){
//            assertEquals(listaLineas.get(i).getCantidad(), listaLineasModificado.get(i).getCantidad());
//            assertEquals(listaLineas.get(i).getSubtotal(), listaLineasModificado.get(i).getSubtotal());
//            assertEquals(listaLineas.get(i).getRazon(), listaLineasModificado.get(i).getRazon());
//        }
//        eliminarTodo();
//    }
//
//    /**
//     * Test of eliminar method, of class LineaDevolucionDAO.
//     */
//    @Test
//    public void testEliminar() {
//        System.out.println("----eliminar----");
//        ArrayList<Integer> listaLineasId = new ArrayList<>();
//        insertarLineas(listaLineasId);
//        // impresión de unos cuantos atributos
//        for (Integer lid : listaLineasId) {
//            System.out.println("Eliminado esta lineaDev con ID "+ lid);
//        }
//        eliminarTodo();
//    }
//
//    private void eliminarTodo() {
//        ArrayList<LineaDevolucionDTO> listaLineas = this.lineaDevolucionDAO.listarTodos();
//        for (Integer i=0; i < listaLineas.size(); i++) {
//            Integer r = this.lineaDevolucionDAO.eliminar(listaLineas.get(i));
//            assertNotEquals(0, r);
//            LineaDevolucionDTO eliminado = this.lineaDevolucionDAO.obtenerPorId(listaLineas.get(i).getLineaDevolucionId());
//            assertNull(eliminado);
//        }
//    }
//    
//}
